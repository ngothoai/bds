<?php $__env->startSection('title', 'Danh sách User'); ?>
<?php $__env->startSection('main-content'); ?>

<div class="row-fluid sortable">		
	<div class="box span12">
		<div class="box-header" data-original-title>
			<h2><i class="halflings-icon white user"></i><span class="break"></span>Tất cả tài khoản</h2>
			<div class="box-icon">
				<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
				<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
			</div>
		</div>
		<div class="box-content" id="list-user">
			<table class="table table-striped table-bordered bootstrap-datatable datatable">
				<thead>
					<tr>
						<th>Tên tài khoản</th>
						<th>Email</th>
						<th>Cấp độ</th>
						<th>Ngày tham gia</th>
						<th>View/block</th>
					</tr>
				</thead>   
				<tbody>
					
				<?php $__currentLoopData = $allUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					
					<tr>
						
						<td><?php echo e($us->name); ?></td>
						<td><?php echo e($us->email); ?></td>
						<td>
							<?php echo e($us->role->rolename); ?>

						</td>
						<td><?php echo e($us->created_at); ?></td>
						<td class="center ">
							<a class="btn btn-info" title="view" href='<?php echo e(url("admin/edit-account/{$us->id}")); ?>'>
								<i class="halflings-icon white edit"></i>  
							</a>
							<a class="btn btn-danger blockU" title="block"  href="<?php echo e($us->email); ?>" onclick="myFun(this);return false">
								<i class="halflings-icon white lock"></i>
							</a>
						</td>
					</tr>
					

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</tbody>
		</table>            
	</div>
</div><!--/span-->

</div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>