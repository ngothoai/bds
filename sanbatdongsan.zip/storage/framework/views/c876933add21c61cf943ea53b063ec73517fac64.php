<?php $__env->startSection('title', 'Thêm bài viết'); ?>
<?php $__env->startSection('main-content'); ?>

<?php if(count($errors)>0): ?>
<div class="alert alert-danger">
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($err); ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php endif; ?>

<?php if(session('thongbao')): ?>

<div class="alert alert-success">
    <?php echo e(session('thongbao')); ?>

</div>
<?php endif; ?>
<form action="<?php echo e(url('admin/new-post')); ?>" enctype="multipart/form-data" method="POST">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
<div class="row-fluid ">
	<div class="box span8" ontablet="span6">
		<div class="box-header" data-original-title>
			<h2><i class="halflings-icon book"></i><span class="break"></span>Thêm bài viết</h2>
			<div class="box-icon">
				<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
				<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
			</div>
		</div>
		<div class="box-content" id="add-post">
			
			
				<div class="control-group">
				  	<label class="control-label" for="typeahead">Tiêu đề </label>
				  	<div class="controls">
						<input type="text" class="span12 typeahead" name="title_post" id="title_post"  >
				  	</div>
				</div>
				<div class="control-group">
                    <label class="control-label" for="typeahead">Nội dung</label>
                    <textarea id="demo" name="Content" rows="2"></textarea>
                    <script type="text/javascript" >
                        
                        var content = CKEDITOR.replace( 'Content', {
                        language:'vi',
                        filebrowserBrowseUrl: '<?php echo e(url('/')); ?>/ckfinder/ckfinder.html',
                        filebrowserUploadUrl: '<?php echo e(url('/')); ?>/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
                        filebrowserImageBrowseUrl : '<?php echo e(url('/')); ?>/ckfinder/ckfinder.html?type=Images',
                        filebrowserImageUploadUrl : '<?php echo e(url('/')); ?>/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
                        });

                        
                    </script>
                </div>
			
			         
		</div>
	</div><!--/span-->
	<div class=" span4 " ontablet="span6">
		<div class="box">
			<div class="box-header" data-original-title>
				<h2><i class="halflings-icon pencil"></i><span class="break"></span>Đăng bài viết</h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content text-center">
				<button type="submit" class="btn btn-primary">Đăng bài viết</button>
			</div>
		</div>
		<div class="box">
			<div class="box-header" data-original-title>
				<h2><i class="halflings-icon check"></i><span class="break"></span>Danh mục bài viết</h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content" id="category-post">
				<div class="control-group">
					<div class="controls">
					<?php 
					function danmuclist($danhmuclist, $parent_idd = 0, $char = '')
						{
						foreach ($danhmuclist as $key => $dm)
						    {
						        // Nếu là chuyên mục con thì hiển thị
						        if ($dm['parent_id'] == $parent_idd)
						        {?>
									<option value="<?php echo e($dm->id); ?>"><?php echo $char;?><?php echo e($dm->title); ?></option>  
						        <?php 
						            // Xóa chuyên mục đã lặp
						            unset($danhmuclist[$key]);
						            // Tiếp tục đệ quy để tìm chuyên mục con của chuyên mục đang lặp
						            danmuclist($danhmuclist, $dm['id'], $char.' --  ');
						    	}
						 	}
						}
							echo '<select class="name-category" name="category_post">';
							echo danmuclist($category);
							echo '</select>';
					  	?>
					 	
					</div>
				  </div>        
			</div>
		</div>
		<div class="box">
			<div class="box-header" data-original-title>
				<h2><i class=" halflings-icon tags"></i><span class="break"></span>Tags</h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content" >
				<div class="control-group">
					<label class="control-label" for="selectError1">Chọn thẻ tags</label>
					<div class="controls">
					  <select id="selectError1" name="tags" multiple data-rel="chosen">
					  <?php  $i=1;  ?>
					  <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					  <?php  $i++;  ?>

						<option value="<?php echo e($tag->id); ?>"><?php echo e($tag->title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					  </select>
					</div>
				  </div>       
			</div>
		<!-- </div> -->	
		<div class="box">
			<div class="box-header" data-original-title>
				<h2><i class=" halflings-icon share-alt"></i><span class="break"></span>Upload Image</h2>
				<div class="box-icon">
					<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
					<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
				</div>
			</div>
			<div class="box-content" >
				<div class="control-group">
					  <label class="control-label" for="fileInput">Upload image</label>
					  <div class="controls">
						<input class="input-file uniform_on" name="img_post" id="fileInput" type="file">
					  </div>
					</div>  
				         
			</div>
		</div>	
	</div>
</div><!--/row-->
</form>		
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>