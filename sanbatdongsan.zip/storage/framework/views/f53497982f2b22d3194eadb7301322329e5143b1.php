<?php $__env->startSection('main-content'); ?>
<div class="row-fluid sortable">
	<div class="box span12">
		<div class="box-header" data-original-title>
			<h2><i class="halflings-icon white edit"></i><span class="break"></span>Thêm tài khoản</h2>
			<div class="box-icon">
				<a href="#" class="btn-setting"><i class="halflings-icon white wrench"></i></a>
				<a href="#" class="btn-minimize"><i class="halflings-icon white chevron-up"></i></a>
				<a href="#" class="btn-close"><i class="halflings-icon white remove"></i></a>
			</div>
		</div>
		<div class="box-content">
			<form class="form-horizontal" action="<?php echo e(url('admin/them-tai-khoan')); ?>" enctype="multipart/form-data" method="POST">
				 <?php if(count($errors)>0): ?>
					<div class="alert alert-danger">

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <?php echo e($err); ?><br>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                        

                    <?php endif; ?>

                    <?php if(session('thongbao')): ?>

                    <div class="alert alert-success">

                        <?php echo e(session('thongbao')); ?>


                    </div>
                    <?php endif; ?>
			  <fieldset>
			   <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<div class="control-group">
				  <label class="control-label" for="typeahead">Tên đăng nhập </label>
				  <div class="controls">
					<input type="text" class="span6 typeahead" name="username" id="username"  >
				  </div>
				</div>
				<div class="control-group">
				  <label class="control-label" for="typeahead">Email </label>
				  <div class="controls">
					<input type="email" class="span6 typeahead" name="email" id="email"  >
				  </div>
				</div>
				<div class="control-group">
				  <label class="control-label" for="typeahead">Mật khẩu </label>
				  <div class="controls">
					<input type="password" class="span6 typeahead" id="password"  name="password">
				  </div>
				</div>
				<div class="control-group">
				  <label class="control-label" for="typeahead">Nhập lại mật khẩu </label>
				  <div class="controls">
					<input type="password" class="span6 typeahead" id="password-again" name="password_again" >
				  </div>
				</div>
                <div class="control-group">
                <label class="control-label" for="typeahead">Cấp độ user </label>
                 <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				  <label class="controls">
					<input type="radio" name="level"  value="<?php echo e($rl->level); ?>" <?php if($rl->level==4): ?> checked="" <?php endif; ?>>
					<?php echo e($rl->rolename); ?>

				  </label>
				  <div style="clear:both"></div>
				  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				
				<div class="form-actions">
				  <button type="submit" class="btn btn-primary">Thêm</button>
				  <button type="reset" class="btn">Cancel</button>
				</div>
			  </fieldset>
			</form>   

		</div>
	</div><!--/span-->

</div><!--/row-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>